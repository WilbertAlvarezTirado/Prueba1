def validate_input(text):
    """
    Validates input text for SQL keywords.
    Returns True if input is valid (no SQL keywords found),
    False if SQL keywords are detected.
    """
    # Convert input to lowercase for case-insensitive comparison
    text = text.lower()
    
    # List of forbidden SQL keywords
    sql_keywords = ['select', 'insert', 'update']
    
    # Check if any SQL keyword is present in the input
    for keyword in sql_keywords:
        if keyword in text:
            return False
    
    return True

def check_input(input_text):
    """
    Checks input and returns appropriate message
    """
    if not validate_input(input_text):
        return "Error campo incorrecto"
    return "Campo válido"

# Example usage
if __name__ == "__main__":
    # Test cases
    test_inputs = [
        "Hello world",
        "SELECT * from users",
        "My password123",
        "INSERT INTO table",
        "Normal text",
        "UPDATE users set",
    ]
    
    print("Testing input validation:")
    print("-" * 30)
    for test_input in test_inputs:
        result = check_input(test_input)
        print(f"Input: {test_input}")
        print(f"Result: {result}")
        print("-" * 30)